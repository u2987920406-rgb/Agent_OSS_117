// src/core/eventBus.ts
import { EventEmitter } from 'events';

// On crée notre instance unique de l'Event Bus (le système nerveux)
export const eventBus = new EventEmitter();

// On autorise plus d'écouteurs (par défaut Node limite à 10, nous aurons plusieurs agents)
eventBus.setMaxListeners(50);

// On définit les canaux de communication standards de notre architecture
export const EVENT_CHANNELS = {
  TASK_CREATED: 'TASK_CREATED',       // Émis par le Cerveau (Orchestrateur)
  TASK_CLAIMED: 'TASK_CLAIMED',       // Émis par un Agent qui prend la tâche
  TASK_COMPLETED: 'TASK_COMPLETED',   // Émis par un Agent qui a fini
  TASK_AUDITED: 'TASK_AUDITED',       // Émis par le Ghost QA qui valide
  TASK_REJECTED: 'TASK_REJECTED'      // Émis par le Ghost QA qui bloque
};

console.log("🚌 Event Bus initialisé. Le système nerveux de l'OS est actif.");
