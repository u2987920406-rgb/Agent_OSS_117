// src/agents/terminalExecutor.ts
import { exec } from 'child_process';
import { eventBus, EVENT_CHANNELS } from '../core/eventBus';
import db from '../core/blackboard';

// On démarre l'agent terminal
export function startTerminalAgent() {
  eventBus.on(EVENT_CHANNELS.TASK_CREATED, (taskId: string) => {
    // 1. L'agent va lire dans le Blackboard si la tâche est pour lui
    const task: any = db.prepare('SELECT * FROM tasks WHERE id = ?').get(taskId);
    
    if (task && task.assigned_to === 'terminal_executor' && task.status === 'PENDING') {
      
      // 2. Il prend la tâche (Lock)
      db.prepare('UPDATE tasks SET status = ? WHERE id = ?').run('RUNNING', taskId);
      const payload = JSON.parse(task.payload);
      
      console.log(`🤖 [Agent Terminal] Exécution de la commande : ${payload.instruction}`);
      
      // 3. Il exécute la commande dans le vrai terminal de ton PC
      exec(payload.instruction, (error, stdout, stderr) => {
        if (error) {
          console.log(`🤖 [Agent Terminal] Erreur détectée. Envoi au Ghost QA...`);
          eventBus.emit(EVENT_CHANNELS.TASK_COMPLETED, taskId, stderr);
        } else {
          console.log(`🤖 [Agent Terminal] Succès. Envoi au Ghost QA...`);
          eventBus.emit(EVENT_CHANNELS.TASK_COMPLETED, taskId, stdout || "Commande exécutée.");
        }
      });
    }
  });
}
