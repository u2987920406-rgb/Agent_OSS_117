// src/agents/codeWriter.ts
import * as fs from 'fs';
import * as path from 'path';
import { eventBus, EVENT_CHANNELS } from '../core/eventBus';
import db from '../core/blackboard';

export function startCodeWriterAgent() {
  eventBus.on(EVENT_CHANNELS.TASK_CREATED, (taskId: string) => {
    // 1. Vérifie si la tâche est pour le Code Writer
    const task: any = db.prepare('SELECT * FROM tasks WHERE id = ?').get(taskId);
    
    if (task && task.assigned_to === 'code_writer' && task.status === 'PENDING') {
      
      // 2. Prend la tâche
      db.prepare('UPDATE tasks SET status = ? WHERE id = ?').run('RUNNING', taskId);
      const payload = JSON.parse(task.payload);
      
      // 3. Extrait les paramètres (nom du fichier et contenu)
      const filename = payload.parameters?.filename || "untitled.txt";
      const content = payload.parameters?.content || "";
      const targetPath = path.join(process.cwd(), filename);
      
      console.log(`✍️ [Code Writer] Création du fichier : ${filename}`);
      
      try {
        // 4. Écrit le fichier sur le disque dur de ton PC
        fs.writeFileSync(targetPath, content, 'utf-8');
        console.log(`✍️ [Code Writer] Succès. Envoi au Ghost QA...`);
        eventBus.emit(EVENT_CHANNELS.TASK_COMPLETED, taskId, `Fichier ${filename} créé avec ${content.length} caractères.`);
      } catch (error) {
        console.log(`✍️ [Code Writer] Erreur d'écriture. Envoi au Ghost QA...`);
        eventBus.emit(EVENT_CHANNELS.TASK_COMPLETED, taskId, `Erreur: ${error}`);
      }
    }
  });
}
