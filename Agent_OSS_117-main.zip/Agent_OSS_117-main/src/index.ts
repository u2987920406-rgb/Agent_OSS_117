// src/index.ts
import 'dotenv/config';
import db from './core/blackboard';
import { eventBus, EVENT_CHANNELS } from './core/eventBus';
import { startTerminalAgent } from './agents/terminalExecutor';
import { startCodeWriterAgent } from './agents/codeWriter';
import { processBrainOutput } from './core/router';

// Démarrage des Agents
startTerminalAgent();
startCodeWriterAgent();

// Démarrage du Ghost QA
eventBus.on(EVENT_CHANNELS.TASK_COMPLETED, (taskId: string, result: string) => {
  console.log(`👻 [Ghost QA] J'audite la tâche ${taskId}... Résultat : ${result.trim()}`);
  db.prepare('UPDATE tasks SET status = ?, qa_status = ?, result = ? WHERE id = ?')
    .run('COMPLETED', 'AUDITED', JSON.stringify({ success: true, output: result }), taskId);
  console.log(`👻 [Ghost QA] Tâche validée.\n`);
});

console.log("Démarrage de l'OS Agentique...\n");

// SIMULATION : Le cerveau demande au Code Writer de créer un fichier index.html
const brainOutput = {
  agent_target: "code_writer",
  action_payload: {
    instruction: "Crée une page web de base",
    parameters: { 
      filename: "index.html", 
      content: "<!DOCTYPE html><html><head><title>Mon OS Agentique</title></head><body><h1>Bonjour OSS 117</h1></body></html>" 
    }
  },
  expect_result_type: "none"
};

processBrainOutput(brainOutput);
