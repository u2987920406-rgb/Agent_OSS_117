import { useState } from 'react';
import './App.css';

function App() {
  const [logs, setLogs] = useState<string[]>(["OS Agentique démarré..."]);
  const [input, setInput] = useState("");

  const sendCommand = () => {
    if (input.trim()) {
      setLogs([...logs, `🧠 [Toi]: ${input}`]);
      setInput("");
      setTimeout(() => {
        setLogs(prev => [...prev, "🤖 [Cerveau]: Requête reçue. En attente de connexion API..."]);
      }, 1000);
    }
  };

  return (
    <div className="os-container">
      <header className="top-bar">
        <h1>AGENT_OSS_117</h1>
        <div className="status">● Event Bus: ACTIF</div>
      </header>

      <div className="main-grid">
        
        <section className="pane brain-pane">
          <h2>🧠 Cerveau Orchestrateur</h2>
          <div className="chat-area">
            {logs.map((log, i) => (
              <p key={i} className="log-line">{log}</p>
            ))}
          </div>
          <div className="input-area">
            <input 
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && sendCommand()}
              placeholder="Tapez votre requête..."
            />
            <button onClick={sendCommand}>Envoyer</button>
          </div>
        </section>

        <section className="pane editor-pane">
          <h2>💻 Plan de Travail</h2>
          <div className="editor-view">
            <p className="placeholder">// En attente de génération de code...</p>
          </div>
        </section>

        <section className="pane monitor-pane">
          <h2>📊 Blackboard (Agents)</h2>
          <div className="task-list">
            <div className="task-item pending">🔵 Tâche 1: En attente...</div>
            <div className="task-item running">🟡 Agent Terminal: Exécution...</div>
            <div className="task-item audited">🟢 Ghost QA: Validé</div>
          </div>
        </section>

      </div>
    </div>
  );
}

export default App;
