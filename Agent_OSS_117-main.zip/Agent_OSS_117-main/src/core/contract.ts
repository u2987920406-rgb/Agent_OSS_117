// src/core/contract.ts
import { z } from 'zod';

// Voici le Schéma Universel que tous les cerveaux orchestrateurs devront respecter.
// Si un cerveau tente d'inventer un agent qui n'existe pas, Zod le bloquera.
export const delegateTaskSchema = z.object({
  agent_target: z.enum([
    "terminal_executor", 
    "web_scraper", 
    "browser_eyes", 
    "code_writer", 
    "rag_memory"
  ]),
  action_payload: z.object({
    instruction: z.string(),
    parameters: z.record(z.string()).optional() // ex: { "url": "https://apple.com" }
  }),
  expect_result_type: z.enum(["text", "image_base64", "json", "none"])
});

// On exporte le type TypeScript pour pouvoir l'utiliser partout dans le code
export type DelegateTaskInput = z.infer<typeof delegateTaskSchema>;
