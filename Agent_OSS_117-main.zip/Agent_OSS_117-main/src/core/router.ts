// src/core/router.ts
import { delegateTaskSchema } from './contract';
import { eventBus, EVENT_CHANNELS } from './eventBus';
import db from './blackboard';
import { randomUUID } from 'crypto';

export function processBrainOutput(rawBrainOutput: any) {
  // 1. Le Routeur tente de valider ce que le cerveau a dit
  const result = delegateTaskSchema.safeParse(rawBrainOutput);

  if (!result.success) {
    console.error("🚨 [Routeur] Le cerveau a généré un JSON invalide ! Tâche rejetée.");
    console.error(result.error);
    return;
  }

  // 2. Si c'est valide, on l'écrit dans le Blackboard (SQLite)
  const taskData = result.data;
  const taskId = randomUUID();
  
  db.prepare('INSERT INTO tasks (id, assigned_to, status, payload) VALUES (?, ?, ?, ?)')
    .run(taskId, taskData.agent_target, 'PENDING', JSON.stringify(taskData.action_payload));

  console.log(`🧠 [Routeur] Tâche valide reçue du Cerveau pour ${taskData.agent_target}.`);

  // 3. On envoie la tâche sur l'Event Bus pour que l'agent aille la faire
  eventBus.emit(EVENT_CHANNELS.TASK_CREATED, taskId);
}
