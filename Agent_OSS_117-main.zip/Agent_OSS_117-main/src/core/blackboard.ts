import Database from 'better-sqlite3';

// On initialise ou on charge la base de données locale
const db = new Database('agent_oss_117.db');

// On active les contraintes de clés étrangères (sécurité DB)
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

// On crée les tables si elles n'existent pas (basé sur notre plan)
const initDb = db.transaction(() => {
  db.exec(`
    CREATE TABLE IF NOT EXISTS tasks (
      id TEXT PRIMARY KEY,
      assigned_to TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'PENDING',
      payload TEXT NOT NULL,
      result TEXT,
      qa_status TEXT DEFAULT 'PENDING',
      qa_report TEXT,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS global_state (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS agent_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      task_id TEXT,
      agent_name TEXT,
      log_level TEXT,
      message TEXT,
      FOREIGN KEY (task_id) REFERENCES tasks(id)
    );
  `);
});

// On exécute la création
initDb();

// Test de fonctionnement
console.log("✅ Blackboard (SQLite) initialisé avec succès. Le noyau de l'OS Agentique est prêt.");

export default db;
