// src/core/brainClient.ts
import OpenAI from 'openai';
import 'dotenv/config';
import { processBrainOutput } from './router';

// Configuration du Cerveau Universel (Compatible OpenAI, GLM, DeepSeek)
const client = new OpenAI({
  apiKey: process.env.BRAIN_API_KEY || "MOCK",
  baseURL: process.env.BRAIN_BASE_URL || "https://api.openai.com/v1"
});

const model = process.env.BRAIN_MODEL || "gpt-4o";

export async function sendToBrain(userPrompt: string) {
  console.log("🧠 [Cerveau Cloud] Connexion au modèle et envoi de la requête...");
  
  try {
    const response = await client.chat.completions.create({
      model: model,
      messages: [
        {
          role: "system",
          content: "Tu es l'Orchestrateur Principal d'un OS Agentique. Tu n'as pas accès à internet ni au système. Pour accomplir la demande, tu DOIS utiliser l'outil delegate_to_agent. Les agents disponibles sont : terminal_executor, web_scraper, browser_eyes, code_writer."
        },
        { role: "user", content: userPrompt }
      ],
      tools: [
        {
          type: "function",
          function: {
            name: "delegate_to_agent",
            description: "Envoie une tâche spécifique à un agent spécialisé",
            parameters: {
              type: "object",
              properties: {
                agent_target: {
                  type: "string",
                  enum: ["terminal_executor", "web_scraper", "browser_eyes", "code_writer", "rag_memory"]
                },
                action_payload: {
                  type: "object",
                  properties: {
                    instruction: { type: "string" }
                  },
                  required: ["instruction"]
                },
                expect_result_type: {
                  type: "string",
                  enum: ["text", "image_base64", "json", "none"]
                }
              },
              required: ["agent_target", "action_payload", "expect_result_type"]
            }
          }
        }
      ],
      tool_choice: "auto"
    });

    // On extrait l'appel d'outil généré par le cerveau
    const toolCall = response.choices[0].message.tool_calls?.[0];

    if (toolCall && toolCall.function.name === "delegate_to_agent") {
      console.log("🧠 [Cerveau Cloud] Décision prise, envoi de l'ordre au Routeur...");
      // On passe le JSON du cerveau à notre filtre Zod !
      processBrainOutput(JSON.parse(toolCall.function.arguments));
    } else {
      console.log("🧠 [Cerveau Cloud] Le cerveau n'a pas utilisé d'outil. Réponse texte :", response.choices[0].message.content);
    }

  } catch (error) {
    console.error("🚨 [Cerveau Cloud] Erreur de connexion API :", error);
  }
}
